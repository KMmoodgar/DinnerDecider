package com.example.dinnerdecider;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    Button decide,addFood, viewFood;
    EditText foodAddEt;
    TextView randomFood;
    ArrayList<String> foodList = new ArrayList<>();
    ArrayAdapter adapter;
    ListView listView;
    Dialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dialog = new Dialog(this);

        decide = findViewById(R.id.decideBtn);
        addFood = findViewById(R.id.addfoodBtn);
        viewFood = findViewById(R.id.viewfoodBtn);
        foodAddEt = findViewById(R.id.addfoodTxt);
        randomFood = findViewById(R.id.foodnameTxt);

        randomFood.setHint("Your Food Here");

        decide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (foodList.isEmpty())
                {
                    AlertDialog.Builder ad = new AlertDialog.Builder(MainActivity.this);
                    ad.setTitle("Dinner Decider");
                    ad.setMessage("Please add food first...!");
                    ad.setCancelable(false);
                    ad.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    });
                    ad.show();
                }
                else if(foodList.size()<2)
                {
                    AlertDialog.Builder ad = new AlertDialog.Builder(MainActivity.this);
                    ad.setTitle("Dinner Decider");
                    ad.setMessage("Please add atleast two foods...!");
                    ad.setCancelable(false);
                    ad.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    });
                    ad.show();
                }
                else {
                    Random r = new Random();
                    int randomItem = r.nextInt(foodList.size());
                    String dinner = foodList.get(randomItem);
                    randomFood.setText(dinner);
                }
            }
        });

        addFood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String foodName = foodAddEt.getText().toString();

                if(foodName.isEmpty())
                {
                    foodAddEt.setError("Please enter the food name");
                    foodAddEt.requestFocus();
                }
                else
                {
                    foodList.add(foodName);
                    Toast.makeText(getApplicationContext(), "Food added successfully", Toast.LENGTH_SHORT).show();
                    foodAddEt.getText().clear();
                }
            }
        });

        viewFood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                dialog.setContentView(R.layout.food_popup);
                listView = dialog.findViewById(R.id.viewFoodList);
                adapter = new ArrayAdapter(MainActivity.this, android.R.layout.simple_list_item_1,foodList);
                listView.setAdapter(adapter);

                listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                    @Override
                    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {

                        final int which_item = position;
                        new android.app.AlertDialog.Builder(MainActivity.this)
                                .setIcon(android.R.drawable.ic_delete)
                                .setTitle("Delete Item")
                                .setMessage("You sure?")
                                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        foodList.remove(which_item);
                                        adapter.notifyDataSetChanged();
                                    }
                                })
                                .setNegativeButton("No",null)
                                .show();
                        return true;
                    }
                });

                dialog.show();
            }
        });
    }
}